// ============================================================
// REVYO BACKEND — Complete working engine
// All features wired. Drop in your keys and go live.
// ============================================================

// ============================================================
// CONFIG — PASTE YOUR KEYS HERE WHEN READY
// ============================================================
const CONFIG = {
  supabase: {
    url:    'YOUR_SUPABASE_URL',        // e.g. https://xxxxx.supabase.co
    key:    'YOUR_SUPABASE_ANON_KEY',   // from Supabase → Settings → API
  },
  twilio: {
    accountSid:  'YOUR_TWILIO_ACCOUNT_SID',
    authToken:   'YOUR_TWILIO_AUTH_TOKEN',
    fromPhone:   'YOUR_TWILIO_PHONE_NUMBER',   // e.g. +12015551234
    waFrom:      'whatsapp:YOUR_TWILIO_WA_NUMBER', // e.g. whatsapp:+14155238886
  },
  anthropic: {
    apiKey: 'YOUR_ANTHROPIC_API_KEY',   // from console.anthropic.com
  },
  stripe: {
    secretKey:      'YOUR_STRIPE_SECRET_KEY',
    publishableKey: 'YOUR_STRIPE_PUBLISHABLE_KEY',
    webhookSecret:  'YOUR_STRIPE_WEBHOOK_SECRET',
  },
  gumroad: {
    accessToken: 'YOUR_GUMROAD_ACCESS_TOKEN',
    starterProductId: 'YOUR_STARTER_PRODUCT_ID',
    growthProductId:  'YOUR_GROWTH_PRODUCT_ID',
    proProductId:     'YOUR_PRO_PRODUCT_ID',
  },
  sendgrid: {
    apiKey:    'YOUR_SENDGRID_API_KEY',   // free tier: 100 emails/day — sendgrid.com
    fromEmail: 'noreply@revyo.ae',
  },
  app: {
    baseUrl: 'https://revyo.ae',
    supportWhatsApp: '+971500000000', // your personal WhatsApp for onboarding
  }
};

// ============================================================
// SUPABASE CLIENT
// ============================================================
// Install: npm install @supabase/supabase-js
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(CONFIG.supabase.url, CONFIG.supabase.key);

// ============================================================
// SUPABASE DATABASE SCHEMA
// Run this SQL in your Supabase SQL editor to create all tables
// ============================================================
const SCHEMA = `
-- Businesses (your paying clients)
CREATE TABLE IF NOT EXISTS businesses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  owner_name TEXT,
  whatsapp TEXT,
  email TEXT,
  niche TEXT, -- salon, clinic, restaurant, barber, dental, gym
  city TEXT DEFAULT 'Dubai',
  plan TEXT DEFAULT 'growth', -- starter, growth, pro
  gumroad_sale_id TEXT,
  status TEXT DEFAULT 'active', -- active, suspended, cancelled
  brand_color TEXT DEFAULT '#ff3d1f',
  booking_slug TEXT UNIQUE, -- e.g. glow-beauty
  wa_connected BOOLEAN DEFAULT false,
  stripe_account_id TEXT,
  deposit_amount INTEGER DEFAULT 100, -- AED
  deposit_enabled BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Clients (customers of your paying businesses)
CREATE TABLE IF NOT EXISTS clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  whatsapp TEXT,
  notes TEXT,
  total_visits INTEGER DEFAULT 0,
  total_spent NUMERIC DEFAULT 0,
  last_visit TIMESTAMPTZ,
  first_visit TIMESTAMPTZ,
  is_lapsed BOOLEAN DEFAULT false,
  lapsed_days INTEGER DEFAULT 0,
  reactivation_sent TIMESTAMPTZ,
  reactivation_booked BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Bookings
CREATE TABLE IF NOT EXISTS bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
  client_id UUID REFERENCES clients(id),
  client_name TEXT NOT NULL,
  client_phone TEXT NOT NULL,
  service TEXT NOT NULL,
  staff TEXT,
  date DATE NOT NULL,
  time TEXT NOT NULL,
  duration_minutes INTEGER DEFAULT 60,
  amount NUMERIC DEFAULT 0,
  deposit_amount NUMERIC DEFAULT 0,
  deposit_paid BOOLEAN DEFAULT false,
  deposit_stripe_id TEXT,
  status TEXT DEFAULT 'pending', -- pending, confirmed, completed, cancelled, no_show
  reminder_24h_sent BOOLEAN DEFAULT false,
  reminder_2h_sent BOOLEAN DEFAULT false,
  reminder_30m_sent BOOLEAN DEFAULT false,
  followup_sent BOOLEAN DEFAULT false,
  wa_source BOOLEAN DEFAULT false, -- booked via WhatsApp converter
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- WhatsApp conversations (for converter tracking)
CREATE TABLE IF NOT EXISTS wa_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
  from_number TEXT NOT NULL,
  message TEXT NOT NULL,
  is_booking_intent BOOLEAN DEFAULT false,
  auto_reply_sent BOOLEAN DEFAULT false,
  followup_sent BOOLEAN DEFAULT false,
  booking_id UUID REFERENCES bookings(id),
  converted BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reactivation campaigns
CREATE TABLE IF NOT EXISTS reactivation_campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
  clients_targeted INTEGER DEFAULT 0,
  messages_sent INTEGER DEFAULT 0,
  bookings_generated INTEGER DEFAULT 0,
  revenue_generated NUMERIC DEFAULT 0,
  status TEXT DEFAULT 'sent', -- draft, sent, completed
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reminders log
CREATE TABLE IF NOT EXISTS reminders_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE,
  type TEXT NOT NULL, -- 24h, 2h, 30m, followup
  channel TEXT NOT NULL, -- sms, whatsapp
  to_number TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT DEFAULT 'sent', -- sent, failed, delivered
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Revenue tracking
CREATE TABLE IF NOT EXISTS revenue_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
  type TEXT NOT NULL, -- deposit_recovered, wa_conversion, reactivation, no_show_prevented
  amount NUMERIC DEFAULT 0,
  booking_id UUID REFERENCES bookings(id),
  client_id UUID REFERENCES clients(id),
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Row Level Security
ALTER TABLE businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE wa_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE reactivation_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE reminders_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE revenue_events ENABLE ROW LEVEL SECURITY;
`;

// ============================================================
// TWILIO — SMS ONLY
// WhatsApp automation coming Q4 2026
// Messages sent from Revyo's Twilio number.
// Business phone always included in message body so clients
// can call/WhatsApp the business directly for changes.
// ============================================================
const twilio = require('twilio')(CONFIG.twilio.accountSid, CONFIG.twilio.authToken);

async function sendSMS(to, message) {
  try {
    const msg = await twilio.messages.create({
      body: message,
      from: CONFIG.twilio.fromPhone,
      to: to.startsWith('+') ? to : '+' + to
    });
    console.log(`SMS sent to ${to}: ${msg.sid}`);
    return { success: true, sid: msg.sid };
  } catch (err) {
    console.error(`SMS failed to ${to}:`, err.message);
    return { success: false, error: err.message };
  }
}

// ============================================================
// ANTHROPIC AI — Personalised message generation
// ============================================================
async function generatePersonalisedMessage(prompt, maxTokens = 200) {
  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': CONFIG.anthropic.apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: maxTokens,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await res.json();
    return data.content[0].text.trim();
  } catch (err) {
    console.error('AI generation failed:', err.message);
    return null;
  }
}

// ============================================================
// MESSAGE HELPERS — SMS ONLY (WhatsApp coming Q4 2026)
// All messages sent via SMS from Twilio number.
// Business phone shown in every message so clients can call/WhatsApp
// the business directly. Management link lets clients self-cancel/reschedule.
// ============================================================

function getManageLink(bookingId) {
  return `${CONFIG.app.baseUrl}/manage/${bookingId}`;
}

function buildSMSConfirmation(booking, business) {
  const manageLink = getManageLink(booking.id);
  const bizPhone = business.whatsapp || business.phone || '';
  const contactLine = bizPhone ? `Call/WhatsApp us: ${bizPhone}` : '';
  return `${business.name}: Hi ${booking.client_name}! Your booking is confirmed.\n\n📅 ${booking.service}\n🕐 ${booking.date} at ${booking.time}\n\nNeed to change or cancel?\n${contactLine}\nOr manage here: ${manageLink}\n\nSee you soon! 🌟`;
}

function buildSMSConfirmationAr(booking, business) {
  const manageLink = getManageLink(booking.id);
  const bizPhone = business.whatsapp || business.phone || '';
  const contactLine = bizPhone ? `تواصل معنا: ${bizPhone}` : '';
  return `${business.name}: أهلاً ${booking.client_name}! تم تأكيد حجزك.\n\n📅 ${booking.service}\n🕐 ${booking.date} الساعة ${booking.time}\n\nتريد التغيير أو الإلغاء؟\n${contactLine}\nأو من هنا: ${manageLink}\n\nنراك قريباً! 🌟`;
}

function build24hSMS(booking, business) {
  const manageLink = getManageLink(booking.id);
  const bizPhone = business.whatsapp || business.phone || '';
  const contactLine = bizPhone ? `Call/WhatsApp: ${bizPhone}` : '';
  return `${business.name}: Reminder — your appointment is tomorrow!\n\n📅 ${booking.service} at ${booking.time}\n\nNeed to reschedule or cancel?\n${contactLine}\nManage: ${manageLink}`;
}

function build2hSMS(booking, business) {
  const bizPhone = business.whatsapp || business.phone || '';
  const contactLine = bizPhone ? `Running late? Call/WhatsApp: ${bizPhone}` : '';
  return `${business.name}: See you in 2 hours!\n\n📅 ${booking.service} at ${booking.time}\n\n${contactLine}`;
}

function build30mSMS(booking, business) {
  const bizPhone = business.whatsapp || business.phone || '';
  return `${business.name}: See you in 30 minutes for your ${booking.service}! We're ready for you.${bizPhone ? ' Any issues? Call: '+bizPhone : ''}`;
}

function buildFollowupSMS(booking, business, bookingSlug) {
  const bizPhone = business.whatsapp || business.phone || '';
  return `${business.name}: Hi ${booking.client_name}! Hope you enjoyed your ${booking.service} 🌟 We'd love to see you again — book your next visit: ${CONFIG.app.baseUrl}/book/${bookingSlug}${bizPhone ? '\n\nQuestions? Call/WhatsApp: '+bizPhone : ''}`;
}

function buildReactivationSMS(client, business, bookingSlug) {
  const bizPhone = business.whatsapp || business.phone || '';
  return `${business.name}: Hi ${client.name}! We've missed you 🌟 Your next visit is waiting — book here: ${CONFIG.app.baseUrl}/book/${bookingSlug}${bizPhone ? '\n\nCall/WhatsApp: '+bizPhone : ''}`;
}

// ============================================================
// FEATURE 1 — BOOKING SYSTEM
// ============================================================

async function createBooking(businessId, bookingData) {
  const {
    clientName, clientPhone, service, staff,
    date, time, amount, isDepositRequired
  } = bookingData;

  // Upsert client
  let clientId = null;
  if (clientPhone) {
    const { data: existingClient } = await supabase
      .from('clients')
      .select('id')
      .eq('business_id', businessId)
      .eq('phone', clientPhone)
      .single();

    if (existingClient) {
      clientId = existingClient.id;
    } else {
      const { data: newClient } = await supabase
        .from('clients')
        .insert({ business_id: businessId, name: clientName, phone: clientPhone })
        .select('id')
        .single();
      if (newClient) clientId = newClient.id;
    }
  }

  // Create booking
  const { data: booking, error } = await supabase
    .from('bookings')
    .insert({
      business_id: businessId,
      client_id: clientId,
      client_name: clientName,
      client_phone: clientPhone,
      service, staff, date, time,
      amount: amount || 0,
      deposit_amount: isDepositRequired ? 100 : 0,
      status: isDepositRequired ? 'pending' : 'confirmed'
    })
    .select()
    .single();

  if (error) throw new Error('Booking creation failed: ' + error.message);

  const { data: business } = await supabase
    .from('businesses')
    .select('name, whatsapp, phone, booking_slug')
    .eq('id', businessId)
    .single();

  if (!isDepositRequired) {
    await sendBookingConfirmation(booking, business);
  }

  return booking;
}

async function sendBookingConfirmation(booking, business) {
  const msg = buildSMSConfirmation(booking, business);
  await sendSMS(booking.client_phone, msg);
  await logReminder(booking.id, 'confirmation', 'sms', booking.client_phone, msg, 'sent');
}

// ============================================================
// FEATURE 1 — NO-SHOW DEPOSIT VIA STRIPE
// ============================================================
const stripe = require('stripe')(CONFIG.stripe.secretKey);

async function createDepositPaymentLink(bookingId, amount, businessName, service) {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'aed',
          product_data: {
            name: `Booking Deposit — ${service}`,
            description: `${businessName} · Applied to your bill at visit. Forfeit if no-show.`
          },
          unit_amount: amount * 100
        },
        quantity: 1
      }],
      mode: 'payment',
      success_url: `${CONFIG.app.baseUrl}/booking/confirmed?session_id={CHECKOUT_SESSION_ID}&booking=${bookingId}`,
      cancel_url: `${CONFIG.app.baseUrl}/booking/cancelled?booking=${bookingId}`,
      metadata: { bookingId, type: 'deposit' }
    });

    await supabase
      .from('bookings')
      .update({ deposit_stripe_id: session.id })
      .eq('id', bookingId);

    return session.url;
  } catch (err) {
    console.error('Stripe deposit creation failed:', err.message);
    return null;
  }
}

async function handleDepositPaid(stripeSessionId) {
  const { data: booking } = await supabase
    .from('bookings')
    .update({ deposit_paid: true, status: 'confirmed' })
    .eq('deposit_stripe_id', stripeSessionId)
    .select()
    .single();

  if (booking) {
    const { data: business } = await supabase
      .from('businesses')
      .select('name, whatsapp, phone, booking_slug')
      .eq('id', booking.business_id)
      .single();
    await sendBookingConfirmation(booking, business);
    await supabase.from('revenue_events').insert({
      business_id: booking.business_id,
      type: 'deposit_recovered',
      amount: booking.deposit_amount,
      booking_id: booking.id,
      description: `Deposit secured for ${booking.service}`
    });
  }
  return booking;
}

// ============================================================
// FEATURE 1 — AUTOMATED REMINDERS ENGINE (SMS ONLY)
// Run every 30 minutes via cron-job.org
// WhatsApp automation coming Q4 2026
// ============================================================
async function runReminderEngine() {
  const now = new Date();
  console.log('Running SMS reminder engine at', now.toISOString());

  const { data: upcomingBookings } = await supabase
    .from('bookings')
    .select('*, businesses(name, whatsapp, phone, booking_slug)')
    .eq('status', 'confirmed')
    .gte('date', now.toISOString().split('T')[0]);

  if (!upcomingBookings?.length) return;

  for (const booking of upcomingBookings) {
    const bookingDateTime = new Date(`${booking.date}T${booking.time}:00`);
    const hoursUntil = (bookingDateTime - now) / (1000 * 60 * 60);

    if (hoursUntil <= 24 && hoursUntil > 23 && !booking.reminder_24h_sent) {
      await send24hReminder(booking);
    }
    if (hoursUntil <= 2 && hoursUntil > 1.5 && !booking.reminder_2h_sent) {
      await send2hReminder(booking);
    }
    if (hoursUntil <= 0.5 && hoursUntil > 0.25 && !booking.reminder_30m_sent) {
      await send30mReminder(booking);
    }
    if (hoursUntil <= -3 && hoursUntil > -4 && !booking.followup_sent) {
      await sendPostVisitFollowup(booking);
    }
  }
}

async function send24hReminder(booking) {
  const biz = booking.businesses;
  const msg = build24hSMS(booking, biz);
  await sendSMS(booking.client_phone, msg);
  await supabase.from('bookings').update({ reminder_24h_sent: true }).eq('id', booking.id);
  await logReminder(booking.id, '24h', 'sms', booking.client_phone, msg, 'sent');
  await supabase.from('revenue_events').insert({
    business_id: booking.business_id,
    type: 'no_show_prevented',
    amount: booking.amount * 0.72,
    booking_id: booking.id,
    description: '24h SMS reminder sent'
  });
  console.log(`24h SMS reminder sent for booking ${booking.id}`);
}

async function send2hReminder(booking) {
  const biz = booking.businesses;
  const msg = build2hSMS(booking, biz);
  await sendSMS(booking.client_phone, msg);
  await supabase.from('bookings').update({ reminder_2h_sent: true }).eq('id', booking.id);
  await logReminder(booking.id, '2h', 'sms', booking.client_phone, msg, 'sent');
  console.log(`2h SMS reminder sent for booking ${booking.id}`);
}

async function send30mReminder(booking) {
  const biz = booking.businesses;
  const msg = build30mSMS(booking, biz);
  await sendSMS(booking.client_phone, msg);
  await supabase.from('bookings').update({ reminder_30m_sent: true }).eq('id', booking.id);
  await logReminder(booking.id, '30m', 'sms', booking.client_phone, msg, 'sent');
  console.log(`30min SMS reminder sent for booking ${booking.id}`);
}

async function sendPostVisitFollowup(booking) {
  const biz = booking.businesses;
  const slug = biz?.booking_slug || booking.business_id;

  // Try AI personalisation first
  const aiPrompt = `Write a warm, brief SMS follow-up from ${biz?.name} to ${booking.client_name} who just had a ${booking.service}. Max 2 sentences. Invite them to rebook. Include booking link: ${CONFIG.app.baseUrl}/book/${slug}. No hashtags. Genuine tone.`;
  let msg = await generatePersonalisedMessage(aiPrompt, 120);
  if (!msg) msg = buildFollowupSMS(booking, biz, slug);

  await sendSMS(booking.client_phone, msg);
  await supabase.from('bookings').update({ followup_sent: true, status: 'completed' }).eq('id', booking.id);
  await logReminder(booking.id, 'followup', 'sms', booking.client_phone, msg, 'sent');
  console.log(`Post-visit SMS follow-up sent for booking ${booking.id}`);
}

async function logReminder(bookingId, type, channel, toNumber, message, status) {
  await supabase.from('reminders_log').insert({
    booking_id: bookingId,
    type, channel,
    to_number: toNumber,
    message, status
  });
}

// ============================================================
// FEATURE 2 — WHATSAPP BOOKING CONVERTER
// This runs as a Twilio webhook — receives incoming WhatsApp messages
// Set this URL in Twilio: POST https://your-backend.com/webhook/whatsapp
// ============================================================
const BOOKING_KEYWORDS = [
  // English
  'book', 'booking', 'available', 'appointment', 'reserve', 'slot',
  'free', 'schedule', 'visit', 'price', 'cost', 'how much',
  // Arabic
  'حجز', 'موعد', 'متاح', 'فارغ', 'سعر', 'كم', 'أحجز', 'احجز',
  'مواعيد', 'خدمة', 'اسعار'
];

async function handleIncomingWhatsApp(req, res) {
  const fromNumber = req.body.From?.replace('whatsapp:', '');
  const message = req.body.Body || '';
  const toNumber = req.body.To?.replace('whatsapp:', '');

  if (!fromNumber || !message) {
    res.status(200).send('<Response></Response>');
    return;
  }

  // Find which business this WhatsApp number belongs to
  const { data: business } = await supabase
    .from('businesses')
    .select('*')
    .eq('whatsapp', toNumber)
    .eq('status', 'active')
    .single();

  if (!business) {
    res.status(200).send('<Response></Response>');
    return;
  }

  const msgLower = message.toLowerCase();
  const isBookingIntent = BOOKING_KEYWORDS.some(kw => msgLower.includes(kw));

  // Log the conversation
  const { data: conv } = await supabase
    .from('wa_conversations')
    .insert({
      business_id: business.id,
      from_number: fromNumber,
      message,
      is_booking_intent: isBookingIntent
    })
    .select()
    .single();

  if (isBookingIntent) {
    // Generate personalised auto-reply
    const aiPrompt = `Write a brief, warm WhatsApp reply from ${business.name} (a ${business.niche} in ${business.city}, UAE). 
    The client sent: "${message}"
    Include: 
    1. Friendly acknowledgment
    2. Direct them to book online: ${CONFIG.app.baseUrl}/book/${business.booking_slug}
    3. Mention availability (say "we have great availability")
    Keep it under 3 sentences. In the same language as the client's message (Arabic if Arabic, English if English). No hashtags.`;

    let reply = await generatePersonalisedMessage(aiPrompt, 200);
    
    if (!reply) {
      // Fallback
      const isArabic = /[\u0600-\u06FF]/.test(message);
      reply = isArabic
        ? `مرحباً! 👋 يسعدنا خدمتك في ${business.name}. احجز موعدك مباشرة هنا:\n📅 ${CONFIG.app.baseUrl}/book/${business.booking_slug}`
        : `Hi! 👋 Thanks for reaching out to ${business.name}! We'd love to help. Book your appointment directly here:\n📅 ${CONFIG.app.baseUrl}/book/${business.booking_slug}`;
    }

    await sendSMS(fromNumber, reply);

    // Update conversation
    await supabase
      .from('wa_conversations')
      .update({ auto_reply_sent: true })
      .eq('id', conv.id);

    // Schedule 2-hour follow-up if no booking made
    scheduleWAFollowup(conv.id, business, fromNumber, message);
  }

  res.status(200).send('<Response></Response>');
}

async function scheduleWAFollowup(convId, business, fromNumber, originalMessage) {
  // Wait 2 hours then check if they booked
  setTimeout(async () => {
    // Check if they booked since the message
    const { data: conv } = await supabase
      .from('wa_conversations')
      .select('converted, followup_sent')
      .eq('id', convId)
      .single();

    if (conv && !conv.converted && !conv.followup_sent) {
      const isArabic = /[\u0600-\u06FF]/.test(originalMessage);
      const followupMsg = isArabic
        ? `مرحباً مجدداً! 😊 هل تحتاج مساعدة في الحجز؟ لا يزال لديك مواعيد متاحة:\n📅 ${CONFIG.app.baseUrl}/book/${business.booking_slug}\nنتطلع لرؤيتك! 🌟`
        : `Hey! 😊 Just checking — did you get a chance to book your spot at ${business.name}? We still have availability:\n📅 ${CONFIG.app.baseUrl}/book/${business.booking_slug}\nLooking forward to seeing you! 🌟`;

      await sendSMS(fromNumber, followupMsg);
      await supabase
        .from('wa_conversations')
        .update({ followup_sent: true })
        .eq('id', convId);

      console.log(`2h WA follow-up sent for conversation ${convId}`);
    }
  }, 2 * 60 * 60 * 1000); // 2 hours
}

// ============================================================
// FEATURE 3 — DEAD CLIENT REACTIVATION
// Run daily via Supabase Edge Functions or cron job
// ============================================================
async function runReactivationEngine(businessId = null) {
  console.log('Running reactivation engine...');

  // Find all active businesses or specific one
  let query = supabase.from('businesses').select('*').eq('status', 'active');
  if (businessId) query = query.eq('id', businessId);
  const { data: businesses } = await query;

  for (const business of businesses || []) {
    // Get plan limits
    const limits = { starter: 100, growth: 500, pro: 9999 };
    const limit = limits[business.plan] || 500;

    // Find lapsed clients — no visit in 45 days
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - 45);

    const { data: lapsedClients } = await supabase
      .from('clients')
      .select('*')
      .eq('business_id', business.id)
      .lt('last_visit', cutoffDate.toISOString())
      .eq('reactivation_booked', false)
      .not('reactivation_sent', 'not.is', null) // hasn't been contacted recently
      .limit(limit);

    // Also find one-time clients specifically
    const { data: oneTimeClients } = await supabase
      .from('clients')
      .select('*')
      .eq('business_id', business.id)
      .eq('total_visits', 1)
      .is('reactivation_sent', null)
      .limit(limit);

    const allTargets = [...(lapsedClients || []), ...(oneTimeClients || [])];
    const uniqueTargets = allTargets.filter((c, i, a) => a.findIndex(x => x.id === c.id) === i);

    if (!uniqueTargets.length) continue;

    let sent = 0;
    const campaignId = (await supabase
      .from('reactivation_campaigns')
      .insert({ business_id: business.id, clients_targeted: uniqueTargets.length })
      .select('id')
      .single()).data?.id;

    for (const client of uniqueTargets) {
      if (!client.whatsapp && !client.phone) continue;

      const daysSince = client.last_visit
        ? Math.floor((new Date() - new Date(client.last_visit)) / (1000 * 60 * 60 * 24))
        : 90;

      // Generate personalised message with AI
      const aiPrompt = `Write a warm, personalised WhatsApp re-engagement message from ${business.name} (a ${business.niche} in ${business.city}, UAE) to a client named ${client.name}. They last visited ${daysSince} days ago${client.total_visits === 1 ? ' and only came once' : ''}. 

The message should:
- Feel personal and genuine (not salesy)
- Mention they've been missed
- Include a soft invitation to return
- Include the booking link: ${CONFIG.app.baseUrl}/book/${business.booking_slug}
- Be max 3 sentences
- Match the client's likely language (use Arabic if the name sounds Arabic, else English)
- No generic marketing language`;

      let msg = await generatePersonalisedMessage(aiPrompt, 200);
      
      if (!msg) {
        // Fallback message
        const isArabicName = /[\u0600-\u06FF]/.test(client.name) || ['Ahmed','Mohammed','Omar','Fatima','Nour','Sara','Lina','Aisha','Khalid','Zaid'].some(n => client.name.includes(n));
        msg = isArabicName
          ? `مرحباً ${client.name}! 🌟 لقد افتقدناك في ${business.name}. يسعدنا رؤيتك مجدداً — احجز موعدك هنا: ${CONFIG.app.baseUrl}/book/${business.booking_slug}`
          : `Hi ${client.name}! 🌟 We've missed you at ${business.name}. We'd love to see you again — book your next visit here: ${CONFIG.app.baseUrl}/book/${business.booking_slug}`;
      }

      const contact = client.whatsapp || client.phone;
      const result = await sendSMS(contact, msg);
      
      if (result.success) {
        await supabase
          .from('clients')
          .update({ reactivation_sent: new Date().toISOString() })
          .eq('id', client.id);
        sent++;
      }

      // Small delay to avoid rate limiting
      await new Promise(r => setTimeout(r, 500));
    }

    // Update campaign stats
    if (campaignId) {
      await supabase
        .from('reactivation_campaigns')
        .update({ messages_sent: sent, status: 'sent' })
        .eq('id', campaignId);
    }

    console.log(`Reactivation: sent ${sent} messages for ${business.name}`);
  }
}

// ============================================================
// FEATURE 5 — LOST CLIENT INTELLIGENCE
// Powers the dashboard's "who came once and never returned" view
// ============================================================
async function getLostClientIntelligence(businessId) {
  const now = new Date();
  const cutoff45 = new Date(now - 45 * 24 * 60 * 60 * 1000);
  const cutoff90 = new Date(now - 90 * 24 * 60 * 60 * 1000);

  // One-time clients (visited exactly once)
  const { data: oneTimers } = await supabase
    .from('clients')
    .select('*')
    .eq('business_id', businessId)
    .eq('total_visits', 1)
    .order('last_visit', { ascending: false });

  // Inactive 45+ days
  const { data: lapsed45 } = await supabase
    .from('clients')
    .select('*')
    .eq('business_id', businessId)
    .lt('last_visit', cutoff45.toISOString())
    .gt('total_visits', 1)
    .order('total_spent', { ascending: false });

  // High-value gone quiet (spent AED 500+ but inactive 90+ days)
  const { data: highValue } = await supabase
    .from('clients')
    .select('*')
    .eq('business_id', businessId)
    .gte('total_spent', 500)
    .lt('last_visit', cutoff90.toISOString())
    .order('total_spent', { ascending: false });

  // Compute potential revenue
  const avgBookingValue = 250; // AED
  const reactivationRate = 0.20; // 20%

  const totalLost = [...new Set([
    ...(oneTimers || []).map(c => c.id),
    ...(lapsed45 || []).map(c => c.id)
  ])].length;

  return {
    summary: {
      oneTimeClients: oneTimers?.length || 0,
      lapsed45Days: lapsed45?.length || 0,
      highValueGoneQuiet: highValue?.length || 0,
      totalAddressable: totalLost,
      potentialRevenue: Math.round(totalLost * reactivationRate * avgBookingValue)
    },
    oneTimeClients: (oneTimers || []).map(c => ({
      ...c,
      daysSince: Math.floor((now - new Date(c.last_visit)) / (1000 * 60 * 60 * 24)),
      category: 'one_time'
    })),
    lapsed45: (lapsed45 || []).map(c => ({
      ...c,
      daysSince: Math.floor((now - new Date(c.last_visit)) / (1000 * 60 * 60 * 24)),
      category: 'lapsed'
    })),
    highValue: (highValue || []).map(c => ({
      ...c,
      daysSince: Math.floor((now - new Date(c.last_visit)) / (1000 * 60 * 60 * 24)),
      category: 'high_value'
    }))
  };
}

// One-click outreach to a list of client IDs
async function sendBulkOutreach(businessId, clientIds, customMessage = null) {
  const { data: business } = await supabase
    .from('businesses')
    .select('*')
    .eq('id', businessId)
    .single();

  const { data: clients } = await supabase
    .from('clients')
    .select('*')
    .in('id', clientIds);

  let sent = 0, failed = 0;

  for (const client of clients || []) {
    const contact = client.whatsapp || client.phone;
    if (!contact) { failed++; continue; }

    let msg = customMessage;
    if (!msg) {
      // Auto-generate if no custom message
      msg = await generatePersonalisedMessage(
        `Write a 2-sentence personalised re-engagement WhatsApp from ${business.name} to ${client.name} who visited ${Math.floor((new Date() - new Date(client.last_visit)) / (1000 * 60 * 60 * 24))} days ago. Include booking link: ${CONFIG.app.baseUrl}/book/${business.booking_slug}`,
        150
      ) || `Hi ${client.name}! We miss you at ${business.name}. Book your next visit: ${CONFIG.app.baseUrl}/book/${business.booking_slug} 🌟`;
    }

    const result = await sendSMS(contact, msg);
    if (result.success) {
      sent++;
      await supabase.from('clients')
        .update({ reactivation_sent: new Date().toISOString() })
        .eq('id', client.id);
    } else {
      failed++;
    }

    await new Promise(r => setTimeout(r, 300)); // rate limit buffer
  }

  return { sent, failed, total: clients?.length || 0 };
}

// ============================================================
// FEATURE 4 — REVENUE RECOVERY DASHBOARD DATA
// ============================================================
async function getRevenueDashboard(businessId, monthYear = null) {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

  // Revenue events this month
  const { data: events } = await supabase
    .from('revenue_events')
    .select('*')
    .eq('business_id', businessId)
    .gte('created_at', startOfMonth.toISOString())
    .lte('created_at', endOfMonth.toISOString());

  // Bookings this month
  const { data: bookings } = await supabase
    .from('bookings')
    .select('*')
    .eq('business_id', businessId)
    .gte('date', startOfMonth.toISOString().split('T')[0])
    .lte('date', endOfMonth.toISOString().split('T')[0]);

  // WA conversions
  const { data: waConversions } = await supabase
    .from('wa_conversations')
    .select('*')
    .eq('business_id', businessId)
    .eq('converted', true)
    .gte('created_at', startOfMonth.toISOString());

  // Reactivation campaigns
  const { data: campaigns } = await supabase
    .from('reactivation_campaigns')
    .select('*')
    .eq('business_id', businessId)
    .gte('created_at', startOfMonth.toISOString());

  const totalRecovered = (events || []).reduce((sum, e) => sum + (e.amount || 0), 0);
  const noShowsPrevented = (events || []).filter(e => e.type === 'no_show_prevented').length;
  const waConverted = waConversions?.length || 0;
  const clientsReactivated = (campaigns || []).reduce((sum, c) => sum + (c.bookings_generated || 0), 0);

  // Get business plan cost
  const planCosts = { starter: 49, growth: 89, pro: 149 };
  const { data: business } = await supabase
    .from('businesses')
    .select('plan')
    .eq('id', businessId)
    .single();
  const monthlyCost = planCosts[business?.plan || 'growth'];
  const monthlyCostAED = Math.round(monthlyCost * 3.67);
  const roi = totalRecovered > 0 ? Math.round(totalRecovered / monthlyCostAED) : 0;

  return {
    period: `${now.toLocaleString('en', { month: 'long' })} ${now.getFullYear()}`,
    totalRecovered: Math.round(totalRecovered),
    noShowsPrevented,
    waLeadsConverted: waConverted,
    clientsReactivated,
    totalBookings: bookings?.length || 0,
    monthlyCost: monthlyCostAED,
    roi,
    events: events || []
  };
}

// ============================================================
// GUMROAD WEBHOOK — Handle new subscribers
// Set this URL in Gumroad: POST https://your-backend.com/webhook/gumroad
// ============================================================
async function handleGumroadSale(req, res) {
  const { sale_id, product_id, full_name, email, variants } = req.body;
  
  // Determine plan from product ID
  const planMap = {
    [CONFIG.gumroad.starterProductId]: 'starter',
    [CONFIG.gumroad.growthProductId]:  'growth',
    [CONFIG.gumroad.proProductId]:     'pro'
  };
  const plan = planMap[product_id] || 'growth';

  // Create business record
  const slug = (full_name || email.split('@')[0])
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .slice(0, 40);

  const { data: business } = await supabase
    .from('businesses')
    .insert({
      name: full_name || 'New Business',
      email,
      plan,
      gumroad_sale_id: sale_id,
      booking_slug: slug + '-' + Date.now().toString(36),
      status: 'active'
    })
    .select()
    .single();

  if (business) {
    // Send onboarding WhatsApp to you (the owner) so you can set them up
    const onboardingMsg = `🚀 NEW REVYO CLIENT!\n\nName: ${full_name}\nEmail: ${email}\nPlan: ${plan.toUpperCase()} ($${plan === 'starter' ? 49 : plan === 'growth' ? 89 : 149}/mo)\nSale ID: ${sale_id}\n\nBusiness ID: ${business.id}\nBooking slug: ${slug}\n\nOnboard them now: ${CONFIG.app.baseUrl}/admin/onboard/${business.id}`;
    
    await sendSMS(CONFIG.app.supportWhatsApp, onboardingMsg);
    console.log(`New client onboarded: ${full_name} (${plan})`);
  }

  res.status(200).json({ success: true });
}

// ============================================================
// FEATURE: EMAIL FALLBACK (backup when SMS fails)
// Uses SendGrid — free tier covers 100 emails/day
// Install: npm install @sendgrid/mail
// ============================================================
const sgMail = (() => {
  try { return require('@sendgrid/mail'); } catch(e) { return null; }
})();

if (sgMail && CONFIG.sendgrid?.apiKey) {
  sgMail.setApiKey(CONFIG.sendgrid.apiKey);
}

async function sendEmailFallback(to, subject, text, htmlContent) {
  if (!sgMail || !CONFIG.sendgrid?.apiKey || !to || !to.includes('@')) return { success: false, reason: 'No email or SendGrid not configured' };
  try {
    await sgMail.send({
      to,
      from: { email: CONFIG.sendgrid.fromEmail || 'noreply@revyo.ae', name: 'Revyo' },
      subject,
      text,
      html: htmlContent || `<p style="font-family:sans-serif;color:#1a1612">${text.replace(/\n/g,'<br>')}</p>`
    });
    return { success: true };
  } catch(err) {
    console.error('Email failed:', err.message);
    return { success: false, error: err.message };
  }
}

// Enhanced SMS + email send — tries SMS first, falls back to email
async function sendWithFallback(phone, email, message, emailSubject) {
  const smsResult = await sendSMS(phone, message);
  if (!smsResult.success && email) {
    console.log(`SMS failed for ${phone}, falling back to email ${email}`);
    await sendEmailFallback(email, emailSubject || 'Appointment reminder', message);
  }
  return smsResult;
}

// ============================================================
// FEATURE: GOOGLE REVIEW REQUEST
// Sent 48h after post-visit follow-up
// Add google_review_link to businesses table
// ============================================================
async function runReviewRequestEngine() {
  const now = new Date();
  const cutoff48h = new Date(now - 48 * 60 * 60 * 1000);
  const cutoff72h = new Date(now - 72 * 60 * 60 * 1000);

  // Find bookings where follow-up was sent 48-72h ago
  const { data: bookings } = await supabase
    .from('bookings')
    .select('*, businesses(name, whatsapp, phone, booking_slug, google_review_link)')
    .eq('status', 'completed')
    .eq('followup_sent', true)
    .is('review_request_sent', null)
    .gte('updated_at', cutoff72h.toISOString())
    .lte('updated_at', cutoff48h.toISOString());

  if (!bookings?.length) return;

  for (const booking of bookings) {
    const biz = booking.businesses;
    if (!biz?.google_review_link) continue;

    const isArabicName = /[\u0600-\u06FF]/.test(booking.client_name) ||
      ['Ahmed','Mohammed','Omar','Fatima','Nour','Sara','Lina','Aisha','Khalid','Zaid','Mariam','Dana'].some(n => booking.client_name.includes(n));

    const msg = isArabicName
      ? `${biz.name}: أهلاً ${booking.client_name}! نأمل أنك استمتعت بزيارتك 🌟 هل يمكنك مشاركة تقييمك معنا؟ رأيك يساعدنا كثيراً:\n${biz.google_review_link}`
      : `${biz.name}: Hi ${booking.client_name}! Hope you loved your visit 🌟 Would you mind leaving us a quick Google review? It means a lot to us:\n${biz.google_review_link}`;

    await sendSMS(booking.client_phone, msg);
    await supabase.from('bookings').update({ review_request_sent: now.toISOString() }).eq('id', booking.id);
    await logReminder(booking.id, 'review_request', 'sms', booking.client_phone, msg, 'sent');
    console.log(`Google review request sent for booking ${booking.id}`);
    await new Promise(r => setTimeout(r, 300));
  }
}

// Add google_review_link to businesses schema:
// ALTER TABLE businesses ADD COLUMN IF NOT EXISTS google_review_link TEXT;
// ALTER TABLE bookings ADD COLUMN IF NOT EXISTS review_request_sent TIMESTAMPTZ;

// ============================================================
// FEATURE: REFERRAL PROGRAMME
// Each client gets a referral code. When a new signup uses it,
// the referrer gets 1 free month (Gumroad subscription paused)
// ============================================================
async function generateReferralCode(businessId) {
  const { data: biz } = await supabase.from('businesses').select('name').eq('id', businessId).single();
  const code = 'REF-' + (biz?.name || '').replace(/[^a-zA-Z]/g,'').toUpperCase().slice(0,4) + '-' + Math.random().toString(36).substr(2,5).toUpperCase();
  await supabase.from('businesses').update({ referral_code: code }).eq('id', businessId);
  return code;
}

async function handleReferralSignup(referralCode, newBusinessId) {
  if (!referralCode) return;
  const { data: referrer } = await supabase.from('businesses').select('*').eq('referral_code', referralCode).single();
  if (!referrer) return;

  // Log the referral
  await supabase.from('referrals').insert({
    referrer_business_id: referrer.id,
    referred_business_id: newBusinessId,
    status: 'pending', // changes to 'rewarded' after referred client's first payment
    created_at: new Date().toISOString()
  });

  console.log(`Referral tracked: ${referrer.name} referred new client`);
}

async function rewardReferral(referredBusinessId) {
  const { data: referral } = await supabase
    .from('referrals')
    .select('*, businesses!referrer_business_id(name, whatsapp)')
    .eq('referred_business_id', referredBusinessId)
    .eq('status', 'pending')
    .single();

  if (!referral) return;

  await supabase.from('referrals').update({ status: 'rewarded', rewarded_at: new Date().toISOString() }).eq('id', referral.id);

  // Notify referrer — in production also pause their Gumroad subscription for 1 month
  const referrer = referral.businesses;
  if (referrer?.whatsapp) {
    const msg = `🎉 ${referrer.name}: Great news! Someone you referred just joined Revyo. Your next month is FREE — your subscription won't be charged next cycle. Thank you! 🙏`;
    await sendSMS(referrer.whatsapp, msg);
  }
  console.log(`Referral rewarded: ${referral.id}`);
}

// Referral schema additions:
// CREATE TABLE IF NOT EXISTS referrals (
//   id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
//   referrer_business_id UUID REFERENCES businesses(id),
//   referred_business_id UUID REFERENCES businesses(id),
//   status TEXT DEFAULT 'pending', -- pending, rewarded
//   rewarded_at TIMESTAMPTZ,
//   created_at TIMESTAMPTZ DEFAULT NOW()
// );
// ALTER TABLE businesses ADD COLUMN IF NOT EXISTS referral_code TEXT UNIQUE;

// ============================================================
// FEATURE: BIRTHDAY & OCCASION DETECTION
// For restaurants/spas: detects occasion at booking,
// auto-sends personalised upsell offer + special treatment
// ============================================================
const OCCASION_MESSAGES = {
  birthday: {
    en: (name, bizName, bizPhone) =>
      `${bizName}: Hi ${name}! 🎂 We saw it's your birthday — we'd love to make it extra special! Ask about our birthday package when you arrive, or call us: ${bizPhone}`,
    ar: (name, bizName, bizPhone) =>
      `${bizName}: أهلاً ${name}! 🎂 علمنا بعيد ميلادك — يسعدنا الاحتفال معك! اسأل عن باقة عيد الميلاد عند وصولك أو اتصل بنا: ${bizPhone}`
  },
  anniversary: {
    en: (name, bizName, bizPhone) =>
      `${bizName}: Hi ${name}! 💍 Congratulations on your anniversary! We have something special prepared. For our anniversary package, call us: ${bizPhone}`,
    ar: (name, bizName, bizPhone) =>
      `${bizName}: أهلاً ${name}! 💍 تهانينا بمناسبة ذكراكم! لدينا مفاجأة خاصة لكم. للاستفسار عن الباقة الخاصة اتصل: ${bizPhone}`
  },
  celebration: {
    en: (name, bizName, bizPhone) =>
      `${bizName}: Hi ${name}! 🎉 We heard there's something to celebrate — we'll make sure it's unforgettable! Any special requests? Call us: ${bizPhone}`,
    ar: (name, bizName, bizPhone) =>
      `${bizName}: أهلاً ${name}! 🎉 علمنا بمناسبتكم — سنجعلها لا تُنسى! أي طلبات خاصة؟ اتصل بنا: ${bizPhone}`
  }
};

async function sendOccasionMessage(booking, business) {
  if (!booking.occasion || booking.occasion === 'none' || booking.occasion === '') return;

  const template = OCCASION_MESSAGES[booking.occasion];
  if (!template) return;

  const bizPhone = business.whatsapp || business.phone || '';
  const isArabicName = /[\u0600-\u06FF]/.test(booking.client_name) ||
    ['Ahmed','Mohammed','Omar','Fatima','Nour','Sara','Lina','Aisha','Khalid'].some(n => booking.client_name.includes(n));

  const msg = isArabicName
    ? template.ar(booking.client_name, business.name, bizPhone)
    : template.en(booking.client_name, business.name, bizPhone);

  // Send 2 hours after booking confirmation
  setTimeout(async () => {
    await sendSMS(booking.client_phone, msg);
    await logReminder(booking.id, 'occasion_upsell', 'sms', booking.client_phone, msg, 'sent');
    console.log(`Occasion message sent for booking ${booking.id} (${booking.occasion})`);
  }, 2 * 60 * 60 * 1000);
}

// Add occasion field to bookings:
// ALTER TABLE bookings ADD COLUMN IF NOT EXISTS occasion TEXT;

// ============================================================
// EXPRESS SERVER SETUP
// ============================================================
const express = require('express');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Webhooks
app.post('/webhook/whatsapp', handleIncomingWhatsApp);
app.post('/webhook/gumroad', handleGumroadSale);
app.post('/webhook/stripe', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try { event = stripe.webhooks.constructEvent(req.body, sig, CONFIG.stripe.webhookSecret); }
  catch(err) { return res.status(400).send(`Webhook Error: ${err.message}`); }
  if (event.type === 'checkout.session.completed') await handleDepositPaid(event.data.object.id);
  res.json({ received: true });
});

// Public booking API
app.get('/api/business/:slug', async (req, res) => {
  try {
    const { data } = await supabase.from('businesses').select('*').eq('booking_slug', req.params.slug).eq('status', 'active').single();
    if (!data) return res.status(404).json({ error: 'Business not found' });
    res.json(data);
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// Booking management
app.get('/api/booking/:id', async (req, res) => {
  try {
    const { data } = await supabase.from('bookings').select('*, businesses(name, whatsapp, phone, booking_slug)').eq('id', req.params.id).single();
    if (!data) return res.status(404).json({ error: 'Booking not found' });
    res.json(data);
  } catch(err) { res.status(500).json({ error: err.message }); }
});

app.patch('/api/booking/:id', async (req, res) => {
  try {
    const { date, time, reason } = req.body;
    const { data } = await supabase.from('bookings').update({ date, time, updated_at: new Date().toISOString() }).eq('id', req.params.id).select('*, businesses(name, whatsapp, phone, booking_slug)').single();
    // Send new confirmation SMS
    if (data) await sendBookingConfirmation(data, data.businesses);
    res.json(data);
  } catch(err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/booking/:id', async (req, res) => {
  try {
    const { reason } = req.body;
    const { data } = await supabase.from('bookings').update({ status: 'cancelled', cancellation_reason: reason }).eq('id', req.params.id).select('*, businesses(name, whatsapp, phone)').single();
    if (data) {
      const biz = data.businesses;
      const msg = `${biz?.name}: Your appointment on ${data.date} at ${data.time} has been cancelled. We hope to see you again soon! Book anytime: ${CONFIG.app.baseUrl}/book/${biz?.booking_slug || ''}`;
      await sendSMS(data.client_phone, msg);
    }
    res.json({ success: true });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// Dashboard endpoints
app.get('/api/dashboard/:businessId', async (req, res) => {
  try { res.json(await getRevenueDashboard(req.params.businessId)); } catch(err) { res.status(500).json({ error: err.message }); }
});
app.get('/api/lost-clients/:businessId', async (req, res) => {
  try { res.json(await getLostClientIntelligence(req.params.businessId)); } catch(err) { res.status(500).json({ error: err.message }); }
});
app.post('/api/outreach/:businessId', async (req, res) => {
  try { res.json(await sendBulkOutreach(req.params.businessId, req.body.clientIds, req.body.message)); } catch(err) { res.status(500).json({ error: err.message }); }
});
app.post('/api/bookings/:businessId', async (req, res) => {
  try { res.json(await createBooking(req.params.businessId, req.body)); } catch(err) { res.status(500).json({ error: err.message }); }
});

// Referral
app.post('/api/referral/generate/:businessId', async (req, res) => {
  try { res.json({ code: await generateReferralCode(req.params.businessId) }); } catch(err) { res.status(500).json({ error: err.message }); }
});

// Cron jobs
app.post('/cron/reminders', async (req, res) => { await runReminderEngine(); res.json({ success: true }); });
app.post('/cron/reactivation', async (req, res) => { await runReactivationEngine(); res.json({ success: true }); });
app.post('/cron/reviews', async (req, res) => { await runReviewRequestEngine(); res.json({ success: true }); });

// Self-serve onboarding — called when Gumroad sale confirmed
app.post('/onboard/:businessId', async (req, res) => {
  try {
    const { businessId } = req.params;
    const code = await generateReferralCode(businessId);
    const { data: biz } = await supabase.from('businesses').select('*').eq('id', businessId).single();
    if (biz) {
      const welcomeMsg = `Welcome to Revyo! 🚀\n\nYour dashboard: ${CONFIG.app.baseUrl}/dashboard\nBooking link: ${CONFIG.app.baseUrl}/book/${biz.booking_slug}\nReferral code: ${code}\n\nShare your booking link on Instagram bio, WhatsApp status, and Google. Reply to this message if you need any help.`;
      await sendSMS(biz.whatsapp, welcomeMsg);
    }
    res.json({ success: true, referralCode: code });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Revyo backend v2 running on port ${PORT}`));

module.exports = {
  createBooking, runReminderEngine, runReactivationEngine,
  getLostClientIntelligence, sendBulkOutreach, getRevenueDashboard,
  handleIncomingWhatsApp, runReviewRequestEngine,
  generateReferralCode, handleReferralSignup, rewardReferral,
  sendOccasionMessage, sendWithFallback, SCHEMA
};
