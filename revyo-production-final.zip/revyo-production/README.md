# Revyo — Production Deployment Guide

## Files in this folder

```
revyo-production/
├── public/
│   ├── index.html        → Landing page (revyo.ae)
│   ├── dashboard.html    → Client dashboard (revyo.ae/dashboard)
│   ├── admin.html        → Your private admin panel (revyo.ae/admin)
│   ├── book.html         → Public booking page (revyo.ae/book/:slug)
│   ├── manage.html       → Booking management (revyo.ae/manage/:id)
│   ├── manifest.json     → PWA manifest (makes it installable on phones)
│   └── sw.js             → Service worker (offline support)
├── api/
│   └── server.js         → Full backend (deploy to Railway separately)
├── vercel.json           → Vercel routing config
├── package.json          → Backend dependencies
└── SETUP.md              → Full setup guide with every step
```

---

## Deploy frontend to Vercel (5 minutes)

1. Go to vercel.com → Log in → Add New Project
2. Drag and drop this entire `revyo-production` folder
3. Vercel detects `vercel.json` automatically — no config needed
4. Click Deploy → your site is live at a `.vercel.app` URL
5. Add your domain: Settings → Domains → Add `revyo.ae`
6. Done ✓

---

## Deploy backend to Railway (20 minutes)

1. Go to railway.app → New Project → Deploy from GitHub
2. Upload the `api/server.js` and `package.json` files
3. Railway auto-installs dependencies and starts the server
4. Add environment variables (your API keys) in Railway dashboard
5. Copy your Railway URL → paste into `REVYO_API` in book.html and manage.html
6. Done ✓

---

## Environment variables needed in Railway

```
SUPABASE_URL=your_supabase_url
SUPABASE_KEY=your_supabase_anon_key
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
TWILIO_PHONE=your_twilio_number
ANTHROPIC_API_KEY=your_anthropic_key
STRIPE_SECRET_KEY=your_stripe_secret
STRIPE_WEBHOOK_SECRET=your_webhook_secret
SENDGRID_API_KEY=your_sendgrid_key
GUMROAD_STARTER_ID=your_product_id
GUMROAD_GROWTH_ID=your_product_id
GUMROAD_PRO_ID=your_product_id
APP_BASE_URL=https://revyo.ae
SUPPORT_PHONE=+971500000000
```

---

## After deployment checklist

- [ ] Landing page loads at revyo.ae
- [ ] Dashboard loads at revyo.ae/dashboard
- [ ] Admin panel loads at revyo.ae/admin (change default password immediately!)
- [ ] Test booking: revyo.ae/book/demo
- [ ] Test management link: revyo.ae/manage/test
- [ ] Add Gumroad product links to landing page (search GUMROAD_LINKS in index.html)
- [ ] Run Supabase schema SQL from server.js SCHEMA variable
- [ ] Set Twilio webhook to: https://your-railway-url/webhook/whatsapp
- [ ] Set Stripe webhook to: https://your-railway-url/webhook/stripe
- [ ] Set Gumroad ping to: https://your-railway-url/webhook/gumroad
- [ ] Set up cron jobs at cron-job.org:
  - POST /cron/reminders every 30 minutes
  - POST /cron/reactivation daily at 10AM UAE (06:00 UTC)
  - POST /cron/reviews daily at 11AM UAE (07:00 UTC)

---

## Admin panel access

URL: revyo.ae/admin
Default password: **revyo2025** ← CHANGE THIS IMMEDIATELY in Settings

---

## Cost summary (monthly)

| Service | Cost |
|---|---|
| Vercel (frontend) | Free |
| Railway (backend) | ~$5/mo |
| Supabase (database) | Free |
| Twilio SMS | ~$8-12/client/mo |
| Anthropic API | ~$5-15/mo total |
| SendGrid (email) | Free (100/day) |
| **Total running cost** | **~$35-50/mo** |

First client at $89/mo covers everything. Second client is pure profit.

---

Built with Revyo · revyo.ae · hello@revyo.ae
