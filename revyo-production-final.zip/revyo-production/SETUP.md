# REVYO — Launch Setup Guide
## Private. Do not publish.

---

## What you have
- `revyo-v3.html` — the landing page (upload to Vercel)
- `revyo-app.html` — the customer dashboard (upload to Vercel)
- `revyo-backend.js` — the working backend (deploy to Railway)
- `package.json` — backend dependencies

---

## Step 1 — Supabase (15 min, free)
1. Go to supabase.com → Create account → New project → Name it "revyo"
2. Wait 2 min for it to spin up
3. Go to SQL Editor → paste the entire SCHEMA string from revyo-backend.js → Run
4. Go to Settings → API → copy:
   - Project URL → paste into CONFIG.supabase.url
   - anon public key → paste into CONFIG.supabase.key
5. Done. Your database is live.

---

## Step 2 — Twilio (20 min, ~$20 to start)
1. Go to twilio.com → Create account → Verify phone
2. Top up $20 credit
3. Get a phone number → choose UAE if available, else US
4. Go to WhatsApp Sandbox → follow setup (or apply for WhatsApp Business API)
5. Copy from Console Dashboard:
   - Account SID → CONFIG.twilio.accountSid
   - Auth Token → CONFIG.twilio.authToken
   - Your Twilio phone number → CONFIG.twilio.fromPhone
   - WhatsApp number → CONFIG.twilio.waFrom
6. Set webhook URL for incoming WhatsApp:
   https://your-backend-url.railway.app/webhook/whatsapp

---

## Step 3 — Anthropic API (10 min, $20 credit)
1. Go to console.anthropic.com → Create account
2. Go to Billing → Add $20 credit (card required)
3. Go to API Keys → Create new key → Copy it
4. Paste into CONFIG.anthropic.apiKey
5. Done. Powers all personalised messages.

---

## Step 4 — Stripe (15 min, no monthly fee)
1. Go to stripe.com → Create account
2. Complete business verification (use your personal details for now)
3. Go to Developers → API Keys → Copy:
   - Publishable key → CONFIG.stripe.publishableKey
   - Secret key → CONFIG.stripe.secretKey
4. Go to Webhooks → Add endpoint:
   https://your-backend-url.railway.app/webhook/stripe
   → Select event: checkout.session.completed
   → Copy webhook secret → CONFIG.stripe.webhookSecret
5. Done. Handles all client deposits.

---

## Step 5 — Gumroad (10 min, free)
1. Go to gumroad.com → Create account
2. Create 3 products:
   - "Revyo Starter" → $49/month → recurring
   - "Revyo Growth" → $89/month → recurring
   - "Revyo Pro" → $149/month → recurring
3. Copy each product ID from the URL:
   - gumroad.com/l/[THIS-PART] → paste into CONFIG
4. Go to Settings → Advanced → Ping URL:
   https://your-backend-url.railway.app/webhook/gumroad
5. Update the 3 GUMROAD_LINKS in revyo-v3.html with real product URLs
6. Done. Your payment system is live.

---

## Step 6 — Deploy Backend to Railway (20 min, ~$5/month)
1. Go to railway.app → Create account → New Project
2. Deploy from GitHub (or drag folder)
3. Upload: revyo-backend.js, package.json
4. Railway auto-detects Node.js, installs deps, starts server
5. Copy your Railway URL (e.g. revyo-backend.railway.app)
6. Update all webhook URLs in Twilio, Stripe, Gumroad with this URL
7. Done. Backend is live 24/7.

---

## Step 7 — Deploy Frontend to Vercel (5 min, free)
1. Go to vercel.com → Create account
2. Drag and drop revyo-v3.html → deploy
3. Also deploy revyo-app.html as a separate project
4. Go to Settings → Domains → add revyo.ae (after buying domain)
5. Done. Your site is live.

---

## Step 8 — Domain (30 min, ~$50/yr)
1. Search for "UAE domain registrar .ae"
2. Register revyo.ae
3. In DNS settings, point to Vercel:
   - A record: 76.76.21.21
   - CNAME: cname.vercel-dns.com
4. Done. Professional URL live.

---

## Step 9 — Set up Cron Jobs (reminders + reactivation)
In Railway or use cron-job.org (free):

POST https://your-backend.railway.app/cron/reminders
→ Every 30 minutes

POST https://your-backend.railway.app/cron/reactivation  
→ Every day at 10:00 AM UAE time (06:00 UTC)

These fire automatically forever. No action needed.

---

## Total cost to launch
- Supabase: $0
- Twilio credit: $20
- Anthropic credit: $20
- Stripe: $0 (2.9% per deposit transaction)
- Gumroad: $0 (10% per subscription)
- Railway: ~$5/month
- Domain: ~$50/year
- Vercel: $0

**First day total: ~$95**
**First client at $89/month: profitable**
**Second client: pure margin**

---

## After going live — first 3 clients checklist
1. Client signs up via Gumroad → you get WhatsApp alert
2. Message them within 2 hours
3. Ask for: business name, WhatsApp number, services + prices, staff names
4. Create their business in Supabase (or via admin panel we'll build next)
5. Send them their booking link: revyo.ae/book/[their-slug]
6. They share it on Instagram bio, WhatsApp status, Google
7. Done — they start getting bookings. You start getting paid.
